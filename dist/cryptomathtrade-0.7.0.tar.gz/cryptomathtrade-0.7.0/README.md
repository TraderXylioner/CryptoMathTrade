# CryptoMathTrade
tools for trades

docs: https://trader-xylioner.notion.site/Docs-e7ecdbbc46064894ae05b9f71e686b54

| exchange | Market | AsyncMarket | WSMarket | Spot | AsyncSpot | WSSpot | Account | AsyncAccount | WSAccount |
|----------|--------|-------------|----------|------|-----------|--------|---------|--------------|-----------|
| ascendex | ❌      | ❌           | ❌        | ❌    | ❌         | ❌      | ❌       | ❌            | ❌         |
| binance  | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ✅            | ❌         |
| bingx    | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ✅            | ❌         |
| bitget   | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ✅            | ❌         |
| bitmart  | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ❌            | ❌         |
| gate     | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ❌       | ❌            | ❌         |
| htx      | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ✅            | ❌         |
| kucoin   | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ✅            | ❌         |
| mexc     | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ✅       | ✅            | ❌         |
| okx      | ✅      | ✅           | ✅        | ❌    | ❌         | ❌      | ❌       | ❌            | ❌         |


_url = URLS.TICKER_URL if "symbol" in params else URLS.TICKERS_URL == ошибка при symbol = None


poetry export -f requirements.txt --output requirements.txt --without-hashes
(Get-Content requirements.txt) -replace ' ; python_version .+', '' | Set-Content requirements.txt
