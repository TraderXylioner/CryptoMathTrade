class URLS:
    # HTTP
    BASE_URL = 'https://ascendex.com'
    DEPTH_URL = '/api/pro/v1/depth'
