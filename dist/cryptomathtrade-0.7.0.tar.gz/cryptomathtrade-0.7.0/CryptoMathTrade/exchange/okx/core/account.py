from ..api.api import API
from ..urls import URLS
from ...utils import get_timestamp


class AccountCore(API):
    def get_coins(self, **params) -> dict:
        """All Coins' Information

        GET /api/v5/asset/currencies

        https://www.okx.com/docs-v5/en/#funding-account-rest-api
        """
        params["timestamp"] = get_timestamp()
        self.headers = self.get_payload(
            path=URLS.COINS_URL, method="GET", params=params
        )
        return self.return_args(
            method="GET",
            url=URLS.BASE_URL + URLS.COINS_URL,
            params=params,
        )
