from ..api.api import API
from ..urls import URLS


class AccountCore(API):
    def get_coins(self, **params) -> dict:
        """All Coins' Information

        GET /account/v1/currencies

        https://developer-pro.bitmart.com/en/spot/#get-account-balance-keyed
        """
        return self.return_args(
            method="GET",
            url=URLS.BASE_URL + URLS.COINS_URL,
            params=params,
        )
